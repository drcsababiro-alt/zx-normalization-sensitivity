IJQI / ZX normalization sensitivity -- publication output

Mode: paper
Scripts required: ONE (zx_normalization_sensitivity.py)

The paper profile requires Qiskit, PyZX, python-sat and mqt.qcec; matplotlib
and pylatexenc are recommended for publication figures. The program deliberately
fails early if proof or equivalence backends are missing in paper mode.

Core: V8.4 Pauli anticommutation model; chi is NOT physical T depth.

variant_metrics.csv: all attempts incl. rejected/unknown with reasons
circuit_summary.csv, family_sensitivity_summary.csv: family and circuit analyses
T_count_matched_pairs.csv: strict same-T pairs
benchmark_manifest.csv, benchmark_family_design.csv: benchmark details
strategy_saturation.csv, leave_one_strategy_out.csv: robustness
performance_summary.csv, failure_forensics.csv, strategy_health.csv: run costs/failures
instances/: full QASM, graphml, Pauli events, coloring certificates per branch
paper_witness/: fresh three-branch witness QASM, ZX snapshots, exact-channel proof,
                exact denominator-T lower bound, clique/coloring and SAT CNFs
paper_ready/: family runtime tables, plots, all-branch independent Pauli audit
PAPER_CLAIM_VALIDATION.json: original paper-number comparisons (never altered)

Witness status: PASS
Claim-consistency status: MATCH
Paper plots: ['family_matched_chromatic_sensitivity.png', 'family_matched_chromatic_sensitivity.pdf', 'T_count_vs_chi.png', 'T_count_vs_chi.pdf']

Do not present a partial run, absent QCEC/unknown status or a numerical
T-count lower bound as an independently verified all-branch proof.
